package shape2d;

public abstract class Shape {

    abstract void print ();
    void identitas() {
        System.out.println("Identitas Shape");
    }
}
