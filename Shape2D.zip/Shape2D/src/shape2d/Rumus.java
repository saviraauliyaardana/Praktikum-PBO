package shape2d;

public interface Rumus {

    double keliling(double x, double y, double z);

    double keliling(double x, double y);
    
    double keliling(double x);
    
    double luas(double x, double y, double z);

    double luas(double x, double y);
    
    double luas(double x);
    
    double volume(double x, double y, double z);

    double volume(double x, double y);
    
    double volume(double x);
    
}
